console.info('Edge function sb_publishable started');
Deno.serve(async (req)=>{
  try {
    if (req.method !== 'POST') {
      return new Response(JSON.stringify({
        error: 'Method not allowed'
      }), {
        status: 405,
        headers: {
          'Content-Type': 'application/json'
        }
      });
    }
    const authHeader = req.headers.get('authorization') || '';
    if (!authHeader.startsWith('Bearer ')) {
      return new Response(JSON.stringify({
        error: 'Unauthorized'
      }), {
        status: 401,
        headers: {
          'Content-Type': 'application/json'
        }
      });
    }
    // In Supabase Edge Functions, the client JWT is passed; we won't verify here, but will record the raw token.
    const jwt = authHeader.substring(7);
    const body = await req.json();
    if (!body?.content) {
      return new Response(JSON.stringify({
        error: 'Missing content'
      }), {
        status: 400,
        headers: {
          'Content-Type': 'application/json'
        }
      });
    }
    // Insert into publishes table using the service role key via the REST API
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    if (!supabaseUrl || !serviceKey) {
      return new Response(JSON.stringify({
        error: 'Supabase environment not configured'
      }), {
        status: 500,
        headers: {
          'Content-Type': 'application/json'
        }
      });
    }
    const insertRes = await fetch(`${supabaseUrl}/rest/v1/publishes`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': serviceKey,
        'Authorization': `Bearer ${serviceKey}`,
        'Prefer': 'return=minimal'
      },
      body: JSON.stringify({
        content: body.content,
        meta: body.meta || null,
        created_at: new Date().toISOString(),
        jwt: jwt
      })
    });
    if (!insertRes.ok) {
      const text = await insertRes.text();
      console.error('Insert failed', insertRes.status, text);
      return new Response(JSON.stringify({
        error: 'DB insert failed'
      }), {
        status: 502,
        headers: {
          'Content-Type': 'application/json'
        }
      });
    }
    // Background notify webhook if WEBHOOK_URL is set
    const webhook = Deno.env.get('WEBHOOK_URL');
    if (webhook) {
      const notify = async ()=>{
        await fetch(webhook, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            content: body.content,
            meta: body.meta || null
          })
        });
      };
      // Fire and forget using EdgeRuntime.waitUntil if available
      try {
        // @ts-ignore
        globalThis.EdgeRuntime?.waitUntil?.(notify());
      } catch (e) {
        // Fallback: don't block response
        notify().catch(console.error);
      }
    }
    return new Response(JSON.stringify({
      status: 'accepted'
    }), {
      status: 202,
      headers: {
        'Content-Type': 'application/json'
      }
    });
  } catch (err) {
    console.error(err);
    return new Response(JSON.stringify({
      error: 'Internal error'
    }), {
      status: 500,
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
});
